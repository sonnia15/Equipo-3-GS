package com.example.demo.Business;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.UserRequesTO;
import com.example.demo.Entity.UserResponseTO;
import com.example.demo.Repository.UserDAO;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserBusiness {
	@Autowired
	UserDAO userDAO;
	public ResponseEntity<?> registryUser (String request, HttpSession session){
		System.out.println(request);
		ObjectMapper objectMapper = new ObjectMapper(); 
		String responseJson = new String();
		try {
			UserRequesTO userRequestTO = objectMapper.readValue(request, UserRequesTO.class);
			int resultsave = userDAO.registryUser(userRequestTO);
			UserResponseTO userResponseTO = new UserResponseTO();
			if (resultsave==1) {
				userResponseTO.setMessage("Registered");
				userResponseTO.setOperationCode("1");
			}else if(resultsave==0)
				userResponseTO.setMessage("Error");
			userResponseTO.setOperationCode("0");
			System.out.println(userRequestTO);
			responseJson =objectMapper.writeValueAsString(userResponseTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Business");
		return new ResponseEntity<Object>(responseJson, HttpStatus.OK);
	}
}