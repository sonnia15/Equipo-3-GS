package com.example.demo.Entity;

public class UserRequesTO {
	public String email;
	public String password;
	public String name;
	public String firstLastName;
	public String secondLastName;
	public String birthday;
	public String birthEntity;
	public String userphotoFront;
	public String userphotoBack;
	
	public UserRequesTO(String email,String password, String name, String firstLastName, String secondLastName, String birthday, String birthEntity, String userphotoFront, String userphotoBack) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.firstLastName = firstLastName;
		this.secondLastName = secondLastName;
		this.birthday = birthday;
		this.birthEntity = birthEntity;
		this.userphotoFront = userphotoFront;
		this.userphotoBack = userphotoBack;
	}
	public UserRequesTO() {
		super();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstLastName() {
		return firstLastName;
	}
	public void setFirstLastName(String firstLastName) {
		this.firstLastName = firstLastName;
	}
	public String getSecondLastName() {
		return secondLastName;
	}
	public void setSecondLastName(String secondLastName) {
		this.secondLastName = secondLastName;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getBirthEntity() {
		return birthEntity;
	}
	public void setBirthEntity(String birthEntity) {
		this.birthEntity = birthEntity;
	}
	public String getUserphotoFront() {
		return userphotoFront;
	}
	public void setUserphotoFront(String userphotoFront) {
		this.userphotoFront = userphotoFront;
	}
	public String getUserphotoBack() {
		return userphotoBack;
	}
	public void setUserphotoBack(String userphotoBack) {
		this.userphotoBack = userphotoBack;
	}
	@Override
	public String toString() {
		System.out.println("RequestTO");
		return "UserRequestTO [email=" + email + ", password=" + password + ","
				+ "name=" + name + ", firstLastName=" + firstLastName + ", "
				+ "secondLastName=" + secondLastName + ", birthday=" + birthday + ","
				+ "birthEntity=" + birthEntity + ", userphotoFront=" + userphotoFront + ","
				+ "userphotoBack=" + userphotoBack + ",]";
	}
}