package com.example.demo.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import com.mongodb.MongoClientURI;

@Configuration
public class SpringMongoConfiguration {
	private static final String URL_MONGO = "mongodb://localhost:27017/agendaMedica";
	public MongoClientURI conectarMongo(){
	return new MongoClientURI(URL_MONGO);
	}
	
@Primary
@Bean
	public MongoTemplate mongotemplate(){
		SimpleMongoDbFactory simpleMongoDbFactory = new SimpleMongoDbFactory(conectarMongo());
		MongoTemplate mongoTemplate = new MongoTemplate(simpleMongoDbFactory);
		((MappingMongoConverter)mongoTemplate.getConverter()).setTypeMapper(new DefaultMongoTypeMapper(null));
		System.out.println("Mongo");
		return mongoTemplate;
		}
}
