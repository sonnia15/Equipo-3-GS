package com.example.demo.Entity;

public class UserResponseTO {
	private String message;
	private String operationCode;
	
	
	@Override
	public String toString() {
		return "UserResponseTO [message=" + message + ", operationCode=" + operationCode + "]";
	}
	public UserResponseTO(String message, String operationCode) {
		super();
		this.message = message;
		this.operationCode = operationCode;
	}
	public UserResponseTO() {
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getOperationCode() {
		return operationCode;
	}
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
		System.out.println("ResponseTO");
	}	
}