package com.example.demo.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.example.demo.Entity.UserMongoTO;
import com.example.demo.Entity.UserRequesTO;

@Repository
public class UserDAO {
	@Autowired
	@Qualifier ("mongotemplate")
	MongoTemplate mongoTemplate;

	public int registryUser(UserRequesTO userRequestTO) {
		int resultsave;
		try {
			UserMongoTO userMongoTO= new UserMongoTO();
			userMongoTO.setEmail(userRequestTO.getEmail());
			userMongoTO.setPassword(userRequestTO.getPassword());
			userMongoTO.setName(userRequestTO.getName());
			userMongoTO.setFirstLastName(userRequestTO.getFirstLastName());
			userMongoTO.setSecondLastName(userRequestTO.getSecondLastName());
			userMongoTO.setBirthday(userRequestTO.getBirthday());
			userMongoTO.setBirthEntity(userRequestTO.getBirthEntity());
			userMongoTO.setUserphotoFront(userRequestTO.getUserphotoFront());
			userMongoTO.setUserphotoBack(userRequestTO.getUserphotoBack());
			mongoTemplate.save(userMongoTO, "users");
			resultsave=1;
			}catch (Exception e) {
				resultsave=0;
				System.out.println("DAO");
			}return resultsave;
	}
}